package com.cg.controller;

import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.entities.Client;
import com.cg.service.IQueryService;

@Controller
public class QueryController {
	ArrayList<String> sme;
	
	@Autowired
	IQueryService iQueryService; 
	
	@RequestMapping(value="/save")
	public String save(@ModelAttribute("client")@Valid Client client,BindingResult result,Model model ) {
		if(result.hasErrors()) {
		model.addAttribute("sme",sme);
		return "index";
		}
		else {
			client=IQueryService.save(client);
		model.addAttribute("message","transcation id is "+client.getQueryId()+"\n transaction done successful");
		return "redirect:/success.html";
		}
	}
	
	@RequestMapping("/index")
	public String getHomePage(Model model) {
		sme=new ArrayList<String>();
		sme.add("Uma");
		sme.add("Rahul");
		sme.add("Kavita");
		sme.add("Hema");
		return "index";
	}
	
	@RequestMapping("/Showbyid")
	public String recharge(Model model ) {
		sme=new ArrayList<String>();
		sme.add("Uma");
		sme.add("Rahul");
		sme.add("Kavita");
		sme.add("Hema");
		((Model) sme).addAttribute("sme",sme );
		model.addAttribute("clent", new Client(0, null, null, null, null, null));
		return "Showbyid";
	}
	
	
	@RequestMapping("/transactionbyid")
	public String transactionbyid(Model model) {
		return "gettransaction";
	}
	
	@RequestMapping("/getid")
	public String getId(Model model,@RequestParam("transactionid")String queryId) {
		model.addAttribute("client",IQueryService.getTransaction(Integer.parseInt(queryId)));
		return "Showbyid";
	}
	
	@RequestMapping("/offers")
	public String offers(Model model) {
		
		model.addAttribute("sme",sme);
		return "offers";
	}

}
