package com.cg.service;

import java.util.List;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.dao.IQueryDAO;
import com.cg.entities.Client;

@Service
@Transactional
public class QueryServiceImpl implements IQueryService{
	
	@Autowired
	IQueryDAO iQueryDAO; 

	public Client save(Client client) {
		
		return iQueryDAO.save(client);
	}

	@Override
	public List<Client> showTransactions() {
		return iQueryDAO.showTransactions();	
	}

	public Client getTransaction(int queryId) {
		return iQueryDAO.getTransaction(queryId);
	}

	
}
