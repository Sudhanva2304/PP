package com.cg.service;

import java.util.List;
import com.cg.entities.Client;


public interface IQueryService {
	
	public static Client save(Client client) {
		// TODO Auto-generated method stub
		return null;
	}
	public List<Client> showTransactions();
	public static Client getTransaction(int queryId) {
		// TODO Auto-generated method stub
		return null;
	}

}
