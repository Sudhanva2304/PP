package com.cg.dao;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import org.springframework.stereotype.Repository;
import com.cg.entities.Client;


@Repository
public class QueryDAOImpl implements IQueryDAO{
	
	@PersistenceContext
	private EntityManager entityManager; 

	@Override
	public Client save(Client client) {
		entityManager.persist(client);
		entityManager.flush();
		return client;
	}

	@Override
	public List<Client> showTransactions() {
		TypedQuery<Client> query=entityManager.createQuery("select c from Customer c",Client.class);
		return query.getResultList();
	}

	@Override
	public Client getTransaction(int queryId) {
		// TODO Auto-generated method stub
		return null;
	}

}
