package com.cg.dao;

import java.util.List;

import com.cg.entities.Client;

public interface IQueryDAO {
	
	public Client save(Client client);
	public List<Client> showTransactions();
	public Client getTransaction(int queryId);

}
