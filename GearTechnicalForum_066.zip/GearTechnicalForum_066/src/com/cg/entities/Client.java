package com.cg.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="query_master")
public class Client implements Serializable{
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="query_id")
	private int queryId;
	@Column(name="technology")
	private String technology;
	@Column(name="query")
	private String question;
	@Column(name="query_raised_by")
	private String raisedByName;
	@Column(name="solutions")
	private String solution;
	@Column(name="solution_given_by")
	private String answeredByName;
	
	public Client(int queryId, String technology, String question, String raisedByName, String solution,
			String answeredByName) {
		super();
		this.queryId = queryId;
		this.technology = technology;
		this.question = question;
		this.raisedByName = raisedByName;
		this.solution = solution;
		this.answeredByName = answeredByName;
	}

	public int getQueryId() {
		return queryId;
	}

	public void setQueryId(int queryId) {
		this.queryId = queryId;
	}

	public String getTechnology() {
		return technology;
	}

	public void setTechnology(String technology) {
		this.technology = technology;
	}

	public String getQuestion() {
		return question;
	}

	public void setQuestion(String question) {
		this.question = question;
	}

	public String getRaisedByName() {
		return raisedByName;
	}

	public void setRaisedByName(String raisedByName) {
		this.raisedByName = raisedByName;
	}

	public String getSolution() {
		return solution;
	}

	public void setSolution(String solution) {
		this.solution = solution;
	}

	public String getAnsweredByName() {
		return answeredByName;
	}

	public void setAnsweredByName(String answeredByName) {
		this.answeredByName = answeredByName;
	}

	@Override
	public String toString() {
		return "QueryServiceImpl [queryId=" + queryId + ", technology=" + technology + ", question=" + question
				+ ", raisedByName=" + raisedByName + ", solution=" + solution + ", answeredByName=" + answeredByName
				+ "]";
	}
	
	
	

}
