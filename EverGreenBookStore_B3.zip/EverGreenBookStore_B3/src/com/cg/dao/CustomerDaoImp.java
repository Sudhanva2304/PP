package com.cg.dao;

public class CustomerDaoImp implements ICustomerDao{

}
