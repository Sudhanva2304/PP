package com.cg.entities;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table
public class Review {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private	int reviewId;
	
	private int rating;
	
	private String headLine;
	
	private String comment;
	
	private Date reviewDate;
	
	@OneToOne
	private Customer customer;
	@ManyToOne(targetEntity=Book.class)
	private Book book;
	public int getReviewId() {
		return reviewId;
	}
	
	public int getRating() {
		return rating;
	}
	public void setRating(int rating) {
		this.rating = rating;
	}
	public String getHeadLine() {
		return headLine;
	}
	public void setHeadLine(String headLine) {
		this.headLine = headLine;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public Date getReviewDate() {
		return reviewDate;
	}
	public void setReviewDate(Date reviewDate) {
		this.reviewDate = reviewDate;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	public Book getBook() {
		return book;
	}
	public void setBook(Book book) {
		this.book = book;
	}

	public Review(int rating, String headLine, String comment, Date reviewDate, Customer customer, Book book) {
		super();
		this.rating = rating;
		this.headLine = headLine;
		this.comment = comment;
		this.reviewDate = reviewDate;
		this.customer = customer;
		this.book = book;
	}

	public Review() {
		super();
	}
	
}
