package com.cg.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table
public class Book implements Serializable {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private	int bookId;
	private	String bookTitle;
	private	int quantity;
	private	Double price;
	private	String category;
	private String author;
    private Date publishDate;
    private String isbn;
    private String fileName;
	private int Rating;
	private String description;
	@ManyToOne(targetEntity=Review.class)
	private Review review;
	public int getBookId() {
		return bookId;
	}
	public void setBookId(int bookId) {
		this.bookId = bookId;
	}
	public String getBookTitle() {
		return bookTitle;
	}
	public void setBookTitle(String bookTitle) {
		this.bookTitle = bookTitle;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public Date getPublishDate() {
		return publishDate;
	}
	public void setPublishDate(Date publishDate) {
		this.publishDate = publishDate;
	}
	public String getIsbn() {
		return isbn;
	}
	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public int getRating() {
		return Rating;
	}
	public void setRating(int rating) {
		Rating = rating;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Review getReview() {
		return review;
	}
	public void setReview(Review review) {
		this.review = review;
	}
	public Book(String bookTitle, int quantity, Double price, String category, String author, Date publishDate,
			String isbn, String fileName, int rating, String description, Review review) {
		super();
		this.bookTitle = bookTitle;
		this.quantity = quantity;
		this.price = price;
		this.category = category;
		this.author = author;
		this.publishDate = publishDate;
		this.isbn = isbn;
		this.fileName = fileName;
		Rating = rating;
		this.description = description;
		this.review = review;
	}
	public Book() {
		super();
	}
	@Override
	public String toString() {
		return "Book [bookId=" + bookId + ", bookTitle=" + bookTitle + ", quantity=" + quantity + ", price=" + price
				+ ", category=" + category + ", author=" + author + ", publishDate=" + publishDate + ", isbn=" + isbn
				+ ", fileName=" + fileName + ", Rating=" + Rating + ", description=" + description + ", review="
				+ review + "]";
	}
	
	
    
}
