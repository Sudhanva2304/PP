package com.cg.util;

public enum TransactionType {
	DEBIT, CREDIT
}
