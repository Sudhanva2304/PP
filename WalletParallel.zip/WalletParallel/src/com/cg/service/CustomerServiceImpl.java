package com.cg.service;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.cg.dao.CustomerDaoImpl;

import com.cg.dao.ICustomerDao;
import com.cg.entities.Account;
import com.cg.entities.Customer;
import com.cg.entities.Transaction;

public class CustomerServiceImpl implements ICustomerService {

	@Autowired
	ICustomerDao iCustomerDao; 
	
	private ICustomerDao customerDao;
	
	public CustomerServiceImpl() {
		customerDao=new CustomerDaoImpl();
	}
	
	@Override
	public boolean createCustomer(Customer customer) {
		
		return customerDao.createCustomer(customer);
	}

	@Override
	public boolean createAccount(Account account) {
		return customerDao.createAccount(account);
	}

	@Override
	public Customer findCustomer(Integer custId) {
		return customerDao.findCustomer(custId);
	}
	@Override
	public Customer isValidLogin(Customer customer) {
		return customerDao.isValidLogin(customer);
	}

	@Override
	public List<Account> getAccounts(int customerId) {
		return customerDao.getAccounts(customerId);
	}

	@Override
	public Account findAccount(long accountno) {
		return customerDao.findAccount(accountno);
	}

	@Override
	public boolean createTransaction(Transaction transaction) {
		return customerDao.createTransaction(transaction);
	}

	@Override
	public double getTotal(Account account) {
		double balance=customerDao.getTotal(account)+account.getOpeningBalance();
		return balance;
	}

	@Override
	public List<Transaction> getTransactionsFromTo(Account account, LocalDate fromDate, LocalDate toDate) {
		return customerDao.getTransactionsFromTo( account,  fromDate,  toDate);
	}

	@Override
	public Customer save(Customer customer) {
		// TODO Auto-generated method stub
		return null;
	}

//	@Override
//	public List<Transaction> getTransactions(long accountNo) {
//		// TODO Auto-generated method stub
//		return customerDao.getTransactions(accountNo);
//	}

}
