package com.cg.dao;

import java.time.LocalDate;
import java.util.List;

import com.cg.entities.Account;
import com.cg.entities.Customer;
import com.cg.entities.Transaction;


public interface ICustomerDao {

	public Customer isValidLogin(Customer customer);
	public boolean createCustomer(Customer customer);
	public boolean createAccount(Account account);
	public Customer findCustomer(Integer custId);
	public List<Account> getAccounts(int customerId);
	public Account findAccount(long accountno);
	public boolean createTransaction(Transaction transaction);
	//public List<Transaction> getTransactions(long accountNo);
	public double getTotal(Account account);
	public List<Transaction> getTransactionsFromTo(Account account, LocalDate fromDate, LocalDate toDate);
}
